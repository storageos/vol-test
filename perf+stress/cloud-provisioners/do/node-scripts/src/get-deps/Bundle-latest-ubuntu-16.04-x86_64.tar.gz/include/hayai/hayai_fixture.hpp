#ifndef __HAYAI_FIXTURE
#define __HAYAI_FIXTURE
#include "hayai_test.hpp"

namespace hayai
{
    typedef Test Fixture;
}
#endif
